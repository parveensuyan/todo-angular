import {
  MatDivider,
  MatDividerModule
} from "./chunk-PXQOB4QZ.js";
import "./chunk-ZVVJ2BJM.js";
import "./chunk-Y3UP4ZJX.js";
import "./chunk-7T7YZIUN.js";
import "./chunk-XDI6XKEU.js";
import "./chunk-A3CSMTED.js";
import "./chunk-QBDLPLTU.js";
import "./chunk-KFHJ6PS7.js";
export {
  MatDivider,
  MatDividerModule
};
